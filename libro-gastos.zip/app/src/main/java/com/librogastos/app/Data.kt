package com.librogastos.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Category(
    val id: String,
    val name: String,
    val isExpense: Boolean,
    val color: Long
)

data class Entry(
    val id: String,
    val amount: Long,
    val isExpense: Boolean,
    val categoryName: String,
    val categoryColor: Long,
    val note: String,
    val epochDay: Long
)

fun newId(): String = UUID.randomUUID().toString()

val Palette: List<Long> = listOf(
    0xFFE57373, 0xFFF2A65A, 0xFFE9C46A, 0xFF8FD694,
    0xFF5FB3A1, 0xFF6FA8DC, 0xFFA78BDA, 0xFFE58FB5
)

fun defaultCategories(): List<Category> = listOf(
    Category(newId(), "Comida", true, 0xFFF2A65A),
    Category(newId(), "Transporte", true, 0xFF6FA8DC),
    Category(newId(), "Hogar", true, 0xFF8FD694),
    Category(newId(), "Servicios", true, 0xFFE9C46A),
    Category(newId(), "Salud", true, 0xFFE57373),
    Category(newId(), "Ocio", true, 0xFFA78BDA),
    Category(newId(), "Sueldo", false, 0xFF5FB3A1),
    Category(newId(), "Otros ingresos", false, 0xFF8FD694)
)

class Store(context: Context) {
    private val prefs = context.getSharedPreferences("libro_gastos", Context.MODE_PRIVATE)

    fun loadCategories(): List<Category> {
        val raw = prefs.getString("categories", null)
        if (raw == null) {
            val defaults = defaultCategories()
            saveCategories(defaults)
            return defaults
        }
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Category(o.getString("id"), o.getString("name"), o.getBoolean("expense"), o.getLong("color"))
            }
        } catch (e: Exception) {
            defaultCategories()
        }
    }

    fun saveCategories(list: List<Category>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("expense", it.isExpense)
                    .put("color", it.color)
            )
        }
        prefs.edit().putString("categories", arr.toString()).apply()
    }

    fun loadEntries(): List<Entry> {
        val raw = prefs.getString("entries", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Entry(
                    o.getString("id"),
                    o.getLong("amount"),
                    o.getBoolean("expense"),
                    o.getString("cat"),
                    o.getLong("color"),
                    o.optString("note", ""),
                    o.getLong("day")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveEntries(list: List<Entry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("amount", it.amount)
                    .put("expense", it.isExpense)
                    .put("cat", it.categoryName)
                    .put("color", it.categoryColor)
                    .put("note", it.note)
                    .put("day", it.epochDay)
            )
        }
        prefs.edit().putString("entries", arr.toString()).apply()
    }
}
