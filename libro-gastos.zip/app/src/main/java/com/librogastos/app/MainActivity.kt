@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.librogastos.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

// ---------- Colores (oscuro suave, nada invasivo) ----------
val Bg = Color(0xFF1E2127)
val Surface1 = Color(0xFF282C33)
val Surface2 = Color(0xFF30353D)
val Accent = Color(0xFF5FB3A1)
val ExpenseC = Color(0xFFEB8A80)
val IncomeC = Color(0xFF7FCF9B)
val TextMain = Color(0xFFE6E8EB)
val TextDim = Color(0xFF9AA1AB)

val ES: Locale = Locale("es", "AR")

fun money(n: Long): String = String.format(ES, "%,d", n)
fun String.cap(): String = replaceFirstChar { it.uppercase() }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color(0xFF10201C),
            background = Bg,
            onBackground = TextMain,
            surface = Surface1,
            onSurface = TextMain,
            surfaceVariant = Surface2,
            onSurfaceVariant = TextDim,
            secondaryContainer = Color(0xFF2F4A45),
            onSecondaryContainer = TextMain,
            outline = Color(0xFF4A505A),
            surfaceContainer = Surface1,
            surfaceContainerHigh = Surface1,
            surfaceContainerHighest = Surface2
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(applicationContext)
        setContent { AppTheme { App(store) } }
    }
}

@Composable
fun App(store: Store) {
    var categories by remember { mutableStateOf(store.loadCategories()) }
    var entries by remember { mutableStateOf(store.loadEntries()) }
    var tab by remember { mutableIntStateOf(0) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    fun setEntries(list: List<Entry>) {
        entries = list
        store.saveEntries(list)
    }

    fun setCategories(list: List<Category>) {
        categories = list
        store.saveCategories(list)
    }

    val tabs = listOf("📒" to "Inicio", "📊" to "Informes", "🏷️" to "Categorías")

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Surface1) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(t.first, fontSize = 20.sp) },
                        label = { Text(t.second) }
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAdd = true },
                containerColor = Accent,
                contentColor = Color(0xFF10201C)
            ) { Text("+", fontSize = 30.sp, fontWeight = FontWeight.Medium) }
        }
    ) { pad ->
        val mod = Modifier.padding(pad)
        when (tab) {
            0 -> HomeScreen(entries, month, { month = it }, { editing = it }, mod)
            1 -> ReportsScreen(entries, mod)
            else -> CategoriesScreen(
                categories,
                onAdd = { setCategories(categories + it) },
                onDelete = { c -> setCategories(categories.filter { it.id != c.id }) },
                modifier = mod
            )
        }
    }

    if (showAdd) {
        val defaultDay = if (month == YearMonth.now()) LocalDate.now().toEpochDay()
        else month.atDay(1).toEpochDay()
        EntryDialog(
            categories = categories,
            initial = null,
            defaultDay = defaultDay,
            onSave = { e ->
                setEntries(listOf(e) + entries)
                month = YearMonth.from(LocalDate.ofEpochDay(e.epochDay))
                showAdd = false
            },
            onDelete = null,
            onDismiss = { showAdd = false }
        )
    }

    editing?.let { cur ->
        EntryDialog(
            categories = categories,
            initial = cur,
            defaultDay = cur.epochDay,
            onSave = { e ->
                setEntries(entries.map { if (it.id == cur.id) e else it })
                editing = null
            },
            onDelete = {
                setEntries(entries.filter { it.id != cur.id })
                editing = null
            },
            onDismiss = { editing = null }
        )
    }
}

// ---------- Componentes comunes ----------
@Composable
fun Navigator(label: String, onPrev: () -> Unit, onNext: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        TextButton(onClick = onPrev) { Text("‹", fontSize = 28.sp, color = TextMain) }
        Text(label, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextMain)
        TextButton(onClick = onNext) { Text("›", fontSize = 28.sp, color = TextMain) }
    }
}

@Composable
fun SummaryRow(expense: Long, income: Long) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        SummaryItem("Gastos", expense, ExpenseC, Modifier.weight(1f))
        SummaryItem("Ingresos", income, IncomeC, Modifier.weight(1f))
        SummaryItem("Saldo", income - expense, TextMain, Modifier.weight(1f))
    }
}

@Composable
fun SummaryItem(label: String, value: Long, color: Color, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextDim, fontSize = 13.sp)
        Text(money(value), color = color, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun EntryRow(e: Entry, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Color(e.categoryColor)),
            contentAlignment = Alignment.Center
        ) {
            Text(e.categoryName.take(1).uppercase(), color = Bg, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.categoryName, fontSize = 16.sp, color = TextMain)
            if (e.note.isNotBlank()) {
                Text(
                    e.note, color = TextDim, fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        Text(
            (if (e.isExpense) "-" else "+") + money(e.amount),
            color = if (e.isExpense) ExpenseC else IncomeC,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text, color = TextDim, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

// ---------- Inicio ----------
@Composable
fun HomeScreen(
    entries: List<Entry>,
    month: YearMonth,
    onMonth: (YearMonth) -> Unit,
    onEdit: (Entry) -> Unit,
    modifier: Modifier
) {
    val monthEntries = entries.filter { YearMonth.from(LocalDate.ofEpochDay(it.epochDay)) == month }
    val exp = monthEntries.filter { it.isExpense }.sumOf { it.amount }
    val inc = monthEntries.filter { !it.isExpense }.sumOf { it.amount }
    val groups = monthEntries.groupBy { it.epochDay }.entries.sortedByDescending { it.key }
    val label = month.format(DateTimeFormatter.ofPattern("MMMM yyyy", ES)).cap()

    Column(modifier.fillMaxSize()) {
        Navigator(label, { onMonth(month.minusMonths(1)) }, { onMonth(month.plusMonths(1)) })
        SummaryRow(exp, inc)
        HorizontalDivider(color = Surface2)
        if (groups.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Sin movimientos este mes.\nTocá + para agregar.", color = TextDim)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                groups.forEach { g ->
                    val date = LocalDate.ofEpochDay(g.key)
                    val dayExp = g.value.filter { it.isExpense }.sumOf { it.amount }
                    val dayInc = g.value.filter { !it.isExpense }.sumOf { it.amount }
                    item(key = "h" + g.key) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(Surface1)
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                date.format(DateTimeFormatter.ofPattern("d MMM  ·  EEEE", ES)).cap(),
                                color = TextDim, fontSize = 13.sp
                            )
                            Text(
                                "Gastos: " + money(dayExp) + "   Ingresos: " + money(dayInc),
                                color = TextDim, fontSize = 12.sp
                            )
                        }
                    }
                    items(g.value, key = { it.id }) { e -> EntryRow(e) { onEdit(e) } }
                }
                item { Spacer(Modifier.height(90.dp)) }
            }
        }
    }
}

// ---------- Informes ----------
@Composable
fun ReportsScreen(entries: List<Entry>, modifier: Modifier) {
    var mode by remember { mutableIntStateOf(1) } // 0 día, 1 semana, 2 mes
    var anchor by remember { mutableStateOf(LocalDate.now()) }

    val range: Pair<LocalDate, LocalDate> = when (mode) {
        0 -> anchor to anchor
        1 -> {
            val s = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            s to s.plusDays(6)
        }
        else -> anchor.withDayOfMonth(1) to anchor.withDayOfMonth(anchor.lengthOfMonth())
    }
    val start = range.first
    val end = range.second

    val label = when (mode) {
        0 -> anchor.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM yyyy", ES)).cap()
        1 -> {
            val f = DateTimeFormatter.ofPattern("d MMM", ES)
            start.format(f) + " – " + end.format(f)
        }
        else -> anchor.format(DateTimeFormatter.ofPattern("MMMM yyyy", ES)).cap()
    }

    fun shift(dir: Long) {
        anchor = when (mode) {
            0 -> anchor.plusDays(dir)
            1 -> anchor.plusWeeks(dir)
            else -> anchor.plusMonths(dir)
        }
    }

    val filtered = entries.filter { it.epochDay in start.toEpochDay()..end.toEpochDay() }
    val expenses = filtered.filter { it.isExpense }
    val incomes = filtered.filter { !it.isExpense }
    val exp = expenses.sumOf { it.amount }
    val inc = incomes.sumOf { it.amount }
    val byDay = filtered.groupBy { it.epochDay }.entries.sortedByDescending { it.key }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Día", "Semana", "Mes").forEachIndexed { i, t ->
                FilterChip(
                    selected = mode == i,
                    onClick = { mode = i },
                    label = { Text(t) }
                )
            }
        }
        Navigator(label, { shift(-1) }, { shift(1) })
        SummaryRow(exp, inc)
        HorizontalDivider(color = Surface2)

        LazyColumn(Modifier.fillMaxSize()) {
            if (filtered.isEmpty()) {
                item {
                    Text(
                        "No hay movimientos en este período.",
                        color = TextDim,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                item { CategoryBars("Gastos por categoría", expenses) }
                item { CategoryBars("Ingresos por categoría", incomes) }
                item { SectionTitle(if (mode == 0) "Movimientos" else "Detalle por día") }
                if (mode == 0) {
                    items(filtered, key = { it.id }) { e -> EntryRow(e) { } }
                } else {
                    byDay.forEach { g ->
                        val date = LocalDate.ofEpochDay(g.key)
                        val dayExp = g.value.filter { it.isExpense }.sumOf { it.amount }
                        val dayInc = g.value.filter { !it.isExpense }.sumOf { it.amount }
                        item(key = "d" + g.key) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    date.format(DateTimeFormatter.ofPattern("EEE d", ES)).cap(),
                                    color = TextMain
                                )
                                Row {
                                    Text("-" + money(dayExp), color = ExpenseC)
                                    Spacer(Modifier.width(14.dp))
                                    Text("+" + money(dayInc), color = IncomeC)
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
fun CategoryBars(title: String, list: List<Entry>) {
    if (list.isEmpty()) return
    val total = list.sumOf { it.amount }
    val groups = list.groupBy { it.categoryName }
        .map { g -> Triple(g.key, g.value.sumOf { it.amount }, g.value.first().categoryColor) }
        .sortedByDescending { it.second }
    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(title, color = TextDim, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        groups.forEach { g ->
            val frac = (g.second.toFloat() / total.toFloat()).coerceIn(0.03f, 1f)
            Column(Modifier.padding(vertical = 6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(g.first, color = TextMain)
                    Text(money(g.second) + "  ·  " + (g.second * 100 / total) + "%", color = TextDim)
                }
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Surface2)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(frac)
                            .fillMaxHeight()
                            .background(Color(g.third))
                    )
                }
            }
        }
    }
}

// ---------- Categorías ----------
@Composable
fun CategoriesScreen(
    categories: List<Category>,
    onAdd: (Category) -> Unit,
    onDelete: (Category) -> Unit,
    modifier: Modifier
) {
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Category?>(null) }

    LazyColumn(modifier.fillMaxSize()) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Mis categorías", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = TextMain)
                Button(
                    onClick = { showAdd = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF10201C))
                ) { Text("+ Nueva") }
            }
        }
        item { SectionTitle("Gastos") }
        items(categories.filter { it.isExpense }, key = { it.id }) { c -> CategoryRow(c) { toDelete = c } }
        item { SectionTitle("Ingresos") }
        items(categories.filter { !it.isExpense }, key = { it.id }) { c -> CategoryRow(c) { toDelete = c } }
        item { Spacer(Modifier.height(90.dp)) }
    }

    if (showAdd) {
        AddCategoryDialog(
            onSave = { onAdd(it); showAdd = false },
            onDismiss = { showAdd = false }
        )
    }

    toDelete?.let { c ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Eliminar categoría") },
            text = { Text("¿Eliminar \"" + c.name + "\"? Los movimientos ya cargados se conservan.") },
            confirmButton = {
                TextButton(onClick = { onDelete(c); toDelete = null }) {
                    Text("Eliminar", color = ExpenseC)
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun CategoryRow(c: Category, onDelete: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(c.color))
        )
        Spacer(Modifier.width(14.dp))
        Text(c.name, Modifier.weight(1f), color = TextMain, fontSize = 16.sp)
        TextButton(onClick = onDelete) { Text("✕", color = TextDim) }
    }
}

@Composable
fun AddCategoryDialog(onSave: (Category) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var isExpense by remember { mutableStateOf(true) }
    var color by remember { mutableLongStateOf(Palette[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva categoría") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = isExpense, onClick = { isExpense = true }, label = { Text("Gasto") })
                    FilterChip(selected = !isExpense, onClick = { isExpense = false }, label = { Text("Ingreso") })
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(24) },
                    label = { Text("Nombre") },
                    singleLine = true
                )
                Spacer(Modifier.height(12.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Palette.forEach { c ->
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .border(if (color == c) 3.dp else 0.dp, TextMain, CircleShape)
                                .clickable { color = c }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onSave(Category(newId(), name.trim(), isExpense, color)) }
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ---------- Alta / edición de movimiento ----------
@Composable
fun EntryDialog(
    categories: List<Category>,
    initial: Entry?,
    defaultDay: Long,
    onSave: (Entry) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var isExpense by remember { mutableStateOf(initial?.isExpense ?: true) }
    var amountText by remember { mutableStateOf(initial?.amount?.toString() ?: "") }
    var note by remember { mutableStateOf(initial?.note ?: "") }
    var day by remember { mutableLongStateOf(initial?.epochDay ?: defaultDay) }
    var selected by remember { mutableStateOf(initial?.categoryName) }
    var showPicker by remember { mutableStateOf(false) }

    val cats = categories.filter { it.isExpense == isExpense }
    val chosen = cats.firstOrNull { it.name == selected }
    val amount = amountText.toLongOrNull() ?: 0L

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nuevo movimiento" else "Editar movimiento") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isExpense,
                        onClick = { isExpense = true; selected = null },
                        label = { Text("Gasto") }
                    )
                    FilterChip(
                        selected = !isExpense,
                        onClick = { isExpense = false; selected = null },
                        label = { Text("Ingreso") }
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { ch -> ch.isDigit() }.take(12) },
                    label = { Text("Monto") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(Modifier.height(12.dp))
                Text("Categoría", color = TextDim, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                if (cats.isEmpty()) {
                    Text("Creá una categoría en la pestaña Categorías.", color = TextDim)
                } else {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        cats.forEach { c ->
                            FilterChip(
                                selected = selected == c.name,
                                onClick = { selected = c.name },
                                label = { Text(c.name) }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it.take(60) },
                    label = { Text("Nota (opcional)") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showPicker = true }) {
                    Text(
                        LocalDate.ofEpochDay(day)
                            .format(DateTimeFormatter.ofPattern("EEE d MMM yyyy", ES)).cap(),
                        color = TextMain
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = amount > 0 && chosen != null,
                onClick = {
                    val c = chosen ?: return@TextButton
                    onSave(
                        Entry(
                            initial?.id ?: newId(),
                            amount, isExpense, c.name, c.color, note.trim(), day
                        )
                    )
                }
            ) { Text("Guardar") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Eliminar", color = ExpenseC) }
                }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        }
    )

    if (showPicker) {
        val st = rememberDatePickerState(initialSelectedDateMillis = day * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { day = it / 86_400_000L }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Cancelar") } }
        ) { DatePicker(state = st) }
    }
}
